package com.lockedme.buisnessleveloperations;

public interface Operations {
    void perform(String s);
}
